﻿# Vietnamese Food
### Thank you for using IA.Baguette Vietnamese Food

### Manual guide:
 1. Config file location
	Windows: "\Documents\Klei\OxygenNotIncluded\mods\config\BaguetteMod\"
 
 2. Config guide
	Field Pho, Soup, PhoNoodle, Rice, BrokenRice, GrilledCutlet, PromoNoodle have the same fomular as following:
	 - Calories: Calories for each kg. (in Kcal)
	 - DeepFreezeAt: The temperature at which food is deeply frozen. (in Kelvin)
	 - RefrigeratedAt: The temperature at which food is refrigerated. (in Kelvin)
	 - Quality: Quality of food, replace it by one of following string: Grisly_F, Terrible_E, Poor_D, Standard_C, Good_B, Great_A, Superb_S, Ambrosial_SS. Or just simple by number from -1 to 6 where -1 is Grisly and 6 is Ambrosial.
	 - SpoilTime: spoil time of food. (in seconds)
	 - CanRot: Food can be rot or not, if this is false, SpoilTime will be ignored.
	 - EffectGain: Id of Effect that will gain after duplicant eat this food. If you are not sure about the right Id, just input the id that are listed in Effects.
		
	Effects have following fomular:
	 - Id: Id of effect. (Please make sure this id is unique not only in this mod but also the game)
	 - Name: Name of effect.
	 - Description: Description of effect.
	 - Duration: Duration time, if this field is missing or 0, the effect will last forever. (In second)
	 - Morale: Amount of morale will be gain or loss. If this field is missing, 0 will be set as default value.
	 - Strength: Amount of strength will be gain or loss. If this field is missing, 0 will be set as default value.
	 - Athletics: Amount of athletics will be gain or loss. If this field is missing, 0 will be set as default value.
	 - Science: Amount of science will be gain or loss. If this field is missing, 0 will be set as default value.
	 - Resistant: Amount of germ resistant will be gain or loss. If this field is missing, 0 will be set as default value.

	> You could see "VietnameseFood.yml" in the same directory with this file for more information (note that this just example file, not the really one - see section 1). You could use http://www.yamllint.com for checking format.
