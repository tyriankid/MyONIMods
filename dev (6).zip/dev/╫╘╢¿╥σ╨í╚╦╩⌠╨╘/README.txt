Thank you for installing Dupery.

If you don't know what to do, please read this instruction manual:
https://github.com/Barleytree/Dupery/wiki/Mod-Instruction-Manual
