# Vietnamese Food
### Cảm ơn bạn đã dùng thức ăn Việt của IA.Baguette

### Hướng dẫn sử dụng:
 1.  Nơi chứa file config
	Windows: "\Documents\Klei\OxygenNotIncluded\mods\config\BaguetteMod\"
 
 2. Hướng dẫn config
	Trường Pho, Soup, PhoNoodle, Rice, BrokenRice, GrilledCutlet, PromoNoodle có cùng công thức như sau:
	 - Calories: Năng lượng cho mỗi ký thực phẩm. (tính bằng Kcal)
	 - DeepFreezeAt: Nhiệt độ đóng băng sâu. (tính bằng Kelvin)
	 - RefrigeratedAt: Nhiệt độ được làm lạnh. (tính bằng Kelvin)
	 - Quality: Chất lươjng thức ăn, thay thế bằng một trong các chuỗi sau: Grisly_F, Terrible_E, Poor_D, Standard_C, Good_B, Great_A, Superb_S, Ambrosial_SS. Hoặc đơn giản nhập từ -1 tới 6 cho đỡ mệt đầu (với -1 là tệ nhất).
	 - SpoilTime: Thời gian thối rữa. (tính bằng giây)
	 - CanRot: Đồ ăn có thể bị thối rữa, hoặc không. Nếu trường này là false, trường SpoilTime sẽ được bỏ qua.
	 - EffectGain: Id của hiệu ứng sẽ nhận nếu dệ ăn đồ ăn này. Nếu bạn không chắc chắn về Id đúng, tốt nhất là chỉ nhập id đã được liệt kê ở trường Effects.
		
	Effects có nhữnng công thức sau:
	 - Id: Id của hiệu ứng. (Hãy đảm bảo id này là duy nhất không chỉ trong mod mà còn cả game nữa)
	 - Name: Tên hiệu ứng.
	 - Description: Mô tả hiệu ứng.
	 - Duration: Thời gian duy trì, nếu trường này thiếu hoặc bằng không, hiệu ứng này sẽ duy trì vĩnh viễn. (tính bằng giây)
	 - Morale: Lượng tinh thần sẽ nhận hoặc mất đi. Nếu trường này thiếu, 0 sẽ là giá trị mặc định.
	 - Strength: Lượng sức mạnh sẽ nhận hoặc mất đi. Nếu trường này thiếu, 0 sẽ là giá trị mặc định.
	 - Athletics: Lượng điền kinh sẽ nhận hoặc mất đi. Nếu trường này thiếu, 0 sẽ là giá trị mặc định.
	 - Science: Lượng khoa học sẽ nhận hoặc mất đi. Nếu trường này thiếu, 0 sẽ là giá trị mặc định.
	 - Resistant: Lượng kháng vi khuẩn sẽ nhận hoặc mất đi. Nếu trường này thiếu, 0 sẽ là giá trị mặc định.

	> Các bạn có thể xem file mẫu có tên "VietnameseFood.yml" ở cùng thư mục với file này để biết thêm cách config (chú ý đây chỉ là file mẫu, không phải setting thực sự - xem lại mục 1). Sau khi sửa đổi có thể dùng http://www.yamllint.com để kiểm tra file yml có đúng chuẩn hay không.
